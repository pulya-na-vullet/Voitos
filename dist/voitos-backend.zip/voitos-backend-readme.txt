Voitos backend (ветка cursor/app-panel-ui-e31c)

1. Распакуйте поверх своей папки проекта (или в новую).
2. НЕ затирайте свой .env и data/voitos.sqlite3, если они уже есть.
3. В папке проекта:
   pip install -r requirements.txt
   python app.py
4. Панель: http://127.0.0.1:18765/panel/
5. Для телефона в той же Wi‑Fi: http://<IP-ПК>:18765/api/v1

Нужные для приложения API: /api/v1/me/executor , /api/v1/executor/offers , /api/v1/executor/register
