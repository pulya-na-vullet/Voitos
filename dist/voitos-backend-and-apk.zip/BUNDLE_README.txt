Voitos — бэкенд (app.py) + Android APK

Бэкенд:
  pip install -r requirements.txt
  cp .env.example .env   # MOBILE_OTP_DEBUG=true
  python app.py          # http://127.0.0.1:18765/

APK:
  apk/voitos-debug.apk
  Эмулятор URL: http://10.0.2.2:18765/api/v1
  Телефон URL:  http://<LAN_IP>:18765/api/v1

См. mobile/CHECKLIST.md
